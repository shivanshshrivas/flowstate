export interface BuyerChatProps {
    userId: string;
    className?: string;
}
export declare function BuyerChat({ userId, className }: BuyerChatProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BuyerChat.d.ts.map