"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { AlertTriangle, CheckCircle, Circle } from "lucide-react";
import { OrderState, ORDER_STATE_LABELS, ORDER_STATE_SEQUENCE } from "./types/index";
import { clsx } from "clsx";
function cn(...args) {
    return clsx(...args);
}
export function EscrowProgressBar({ state, payoutSchedule, isDisputed, compact = false, className, }) {
    const isDisputedState = state === OrderState.DISPUTED || Boolean(isDisputed);
    const currentIdx = ORDER_STATE_SEQUENCE.indexOf(state);
    const activeIdx = currentIdx === -1 ? 0 : currentIdx;
    const payoutByState = new Map((payoutSchedule ?? []).map((payout) => [payout.state, payout]));
    return (_jsx("div", { className: cn("space-y-2", className), children: _jsx("div", { className: "overflow-x-auto pb-1", children: _jsxs("div", { className: cn("relative", compact ? "min-w-0" : "w-max min-w-full"), children: [isDisputedState && (_jsx("div", { className: "pointer-events-none absolute inset-x-2 top-0 z-20 flex justify-center", children: _jsxs("div", { className: cn("inline-flex items-center gap-1.5 rounded-full border border-red-700/70 bg-red-950/90 px-3 py-1 text-[11px] font-medium text-red-200", compact && "text-[10px]"), children: [_jsx(AlertTriangle, { className: cn("h-3.5 w-3.5 shrink-0", compact && "h-3 w-3") }), "Disputed: funds frozen pending review"] }) })), _jsx("div", { className: cn("flex items-start", isDisputedState && (compact ? "pt-6" : "pt-8"), isDisputedState && "opacity-55"), children: ORDER_STATE_SEQUENCE.map((step, idx) => {
                            const stepLabel = ORDER_STATE_LABELS[step];
                            const isPast = !isDisputedState && idx < activeIdx;
                            const isCurrent = !isDisputedState && idx === activeIdx;
                            const isCompletedConnector = !isDisputedState && idx < activeIdx;
                            const payout = payoutByState.get(step);
                            const isLast = idx === ORDER_STATE_SEQUENCE.length - 1;
                            return (_jsxs("div", { className: cn("flex items-start", compact
                                    ? isLast
                                        ? "shrink-0"
                                        : "min-w-0 flex-1"
                                    : "flex-none min-w-[7rem] md:min-w-[7.5rem]"), children: [_jsxs("div", { className: cn("flex shrink-0 flex-col items-center", !compact && "w-full"), children: [_jsxs("div", { title: stepLabel, "aria-label": stepLabel, className: cn("relative flex items-center justify-center rounded-full border-2 font-semibold transition-colors", compact ? "h-4 w-4 text-[9px]" : "h-8 w-8 text-xs", isPast
                                                    ? "border-emerald-500 bg-emerald-500 text-white"
                                                    : isCurrent
                                                        ? "border-violet-500 bg-violet-500 text-white"
                                                        : "border-neutral-700 bg-neutral-900 text-neutral-500"), children: [isPast ? (_jsx(CheckCircle, { className: cn(compact ? "h-2.5 w-2.5" : "h-4 w-4") })) : (_jsxs(_Fragment, { children: [_jsx(Circle, { className: cn("absolute inset-0 m-auto", compact ? "h-3.5 w-3.5" : "h-6 w-6", isCurrent ? "text-white/80" : "text-neutral-600") }), _jsx("span", { className: "relative z-10 leading-none", children: idx + 1 })] })), isCurrent && (_jsxs(_Fragment, { children: [_jsx("span", { className: cn("pointer-events-none absolute inset-0 rounded-full ring-4 ring-violet-500/20", compact && "ring-2") }), _jsx("span", { className: cn("pointer-events-none absolute -inset-1 rounded-full border border-violet-400/40 animate-pulse", compact && "-inset-0.5") })] }))] }), !compact && (_jsxs("div", { className: "mt-2 hidden w-full px-1 text-center sm:block", children: [_jsx("p", { className: cn("break-words text-[11px] font-medium leading-tight", isPast
                                                            ? "text-emerald-400"
                                                            : isCurrent
                                                                ? "text-violet-300"
                                                                : "text-neutral-500"), children: stepLabel }), payout && (_jsxs("p", { className: "mt-0.5 text-[10px] text-neutral-500", children: [(payout.percentageBps / 100).toFixed(0), "% payout"] }))] })), !compact && isCurrent && (_jsx("span", { className: "mt-2 hidden rounded-full border border-violet-500/30 bg-violet-500/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-violet-200 sm:inline-flex", children: "Current" }))] }), !isLast && (_jsx("div", { className: cn(compact
                                            ? "mx-1 mt-1.5 h-0.5 min-w-[0.75rem] flex-1 rounded-full sm:mx-1"
                                            : "mx-1.5 mt-3.5 h-0.5 w-4 rounded-full sm:w-5 md:w-7 lg:w-8", isCompletedConnector ? "bg-emerald-500" : "bg-neutral-800") }))] }, step));
                        }) })] }) }) }));
}
//# sourceMappingURL=EscrowProgressBar.js.map