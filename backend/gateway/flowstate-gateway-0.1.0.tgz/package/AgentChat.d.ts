export interface AgentChatProps {
    role: "buyer" | "seller" | "admin";
    userId: string;
    variant?: "floating" | "inline" | "panel";
    className?: string;
    placeholder?: string;
}
export declare function AgentChat({ role, userId, variant, className, placeholder, }: AgentChatProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AgentChat.d.ts.map