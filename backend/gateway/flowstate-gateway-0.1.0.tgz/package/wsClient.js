export class FlowStateWsClient {
    constructor({ baseUrl, apiKey, reconnectDelayMs = 1000, maxReconnectDelayMs = 30000, }) {
        this.ws = null;
        this.listeners = new Map();
        this.shouldReconnect = false;
        this.reconnectTimer = null;
        this.baseUrl = baseUrl.replace(/^http/, "ws").replace(/\/$/, "");
        this.apiKey = apiKey;
        this.reconnectDelay = reconnectDelayMs;
        this.maxReconnectDelay = maxReconnectDelayMs;
        this.currentDelay = reconnectDelayMs;
    }
    connect() {
        this.shouldReconnect = true;
        this.openSocket();
    }
    disconnect() {
        this.shouldReconnect = false;
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
        this.emit("disconnected", null);
    }
    on(event, listener) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, new Set());
        }
        this.listeners.get(event).add(listener);
        return () => this.off(event, listener);
    }
    off(event, listener) {
        this.listeners.get(event)?.delete(listener);
    }
    emit(event, data) {
        this.listeners.get(event)?.forEach((fn) => fn(data));
    }
    openSocket() {
        try {
            this.ws = new WebSocket(`${this.baseUrl}/ws`);
            this.ws.onopen = () => {
                this.currentDelay = this.reconnectDelay;
                this.ws.send(JSON.stringify({ type: "auth", token: this.apiKey }));
                this.emit("connected", null);
            };
            this.ws.onmessage = (event) => {
                try {
                    const msg = JSON.parse(event.data);
                    this.emit(msg.type, msg.payload);
                }
                catch {
                    // ignore malformed messages
                }
            };
            this.ws.onerror = (event) => {
                this.emit("error", event);
            };
            this.ws.onclose = () => {
                this.ws = null;
                if (this.shouldReconnect) {
                    this.scheduleReconnect();
                }
                else {
                    this.emit("disconnected", null);
                }
            };
        }
        catch (err) {
            this.emit("error", err);
            if (this.shouldReconnect) {
                this.scheduleReconnect();
            }
        }
    }
    scheduleReconnect() {
        this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.openSocket();
            this.currentDelay = Math.min(this.currentDelay * 2, this.maxReconnectDelay);
        }, this.currentDelay);
    }
}
//# sourceMappingURL=wsClient.js.map