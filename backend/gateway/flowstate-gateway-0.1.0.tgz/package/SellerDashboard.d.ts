export interface SellerDashboardProps {
    sellerId: string;
    onConfirmLabel?: (orderId: string) => void;
    onRespondDispute?: (disputeId: string) => void;
    className?: string;
}
export declare function SellerDashboard({ sellerId, onConfirmLabel, onRespondDispute, className }: SellerDashboardProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SellerDashboard.d.ts.map