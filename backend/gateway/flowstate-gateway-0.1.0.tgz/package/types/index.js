// ─── Order State Machine ───────────────────────────────────────────────────
export var OrderState;
(function (OrderState) {
    OrderState["INITIATED"] = "INITIATED";
    OrderState["ESCROWED"] = "ESCROWED";
    OrderState["LABEL_CREATED"] = "LABEL_CREATED";
    OrderState["SHIPPED"] = "SHIPPED";
    OrderState["IN_TRANSIT"] = "IN_TRANSIT";
    OrderState["DELIVERED"] = "DELIVERED";
    OrderState["FINALIZED"] = "FINALIZED";
    OrderState["DISPUTED"] = "DISPUTED";
})(OrderState || (OrderState = {}));
export const ORDER_STATE_LABELS = {
    [OrderState.INITIATED]: "Order Placed",
    [OrderState.ESCROWED]: "Payment Escrowed",
    [OrderState.LABEL_CREATED]: "Label Printed",
    [OrderState.SHIPPED]: "Shipped",
    [OrderState.IN_TRANSIT]: "In Transit",
    [OrderState.DELIVERED]: "Delivered",
    [OrderState.FINALIZED]: "Finalized",
    [OrderState.DISPUTED]: "Disputed",
};
export const ORDER_STATE_SEQUENCE = [
    OrderState.INITIATED,
    OrderState.ESCROWED,
    OrderState.LABEL_CREATED,
    OrderState.SHIPPED,
    OrderState.IN_TRANSIT,
    OrderState.DELIVERED,
    OrderState.FINALIZED,
];
// ─── Disputes ─────────────────────────────────────────────────────────────
export var DisputeStatus;
(function (DisputeStatus) {
    DisputeStatus["OPEN"] = "OPEN";
    DisputeStatus["SELLER_RESPONDED"] = "SELLER_RESPONDED";
    DisputeStatus["RESOLVED"] = "RESOLVED";
    DisputeStatus["AUTO_RESOLVED"] = "AUTO_RESOLVED";
})(DisputeStatus || (DisputeStatus = {}));
//# sourceMappingURL=index.js.map