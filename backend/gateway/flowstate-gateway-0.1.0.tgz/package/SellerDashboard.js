"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useMemo, useState, useCallback } from "react";
import { AlertTriangle, CheckCircle, Clock, DollarSign, Download, ExternalLink, Package, TrendingUp, Loader2, } from "lucide-react";
import { useFlowState } from "./FlowStateProvider";
import { EscrowProgressBar } from "./EscrowProgressBar";
import { AgentChat } from "./AgentChat";
import { OrderState, ORDER_STATE_LABELS, } from "./types/index";
import { clsx } from "clsx";
function cn(...args) {
    return clsx(...args);
}
function formatUsd(usd) {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(usd);
}
function formatDate(iso) {
    return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}
function formatDateTime(iso) {
    return new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
const XRPL_EXPLORER = "https://explorer.testnet.xrplevm.org";
const NEXT_STATES = {
    [OrderState.ESCROWED]: OrderState.LABEL_CREATED,
    [OrderState.LABEL_CREATED]: OrderState.SHIPPED,
};
const ACTION_LABELS = {
    [OrderState.ESCROWED]: "Confirm Label Printed",
    [OrderState.LABEL_CREATED]: "Confirm Shipped",
};
const FILTERS = [
    { key: "all", label: "All" },
    { key: "needs_action", label: "Needs Action" },
    { key: "in_transit", label: "In Transit" },
    { key: "completed", label: "Completed" },
];
function StateBadge({ state }) {
    const colors = {
        [OrderState.INITIATED]: "bg-neutral-700 text-neutral-300",
        [OrderState.ESCROWED]: "bg-violet-900/60 text-violet-300",
        [OrderState.LABEL_CREATED]: "bg-blue-900/60 text-blue-300",
        [OrderState.SHIPPED]: "bg-cyan-900/60 text-cyan-300",
        [OrderState.IN_TRANSIT]: "bg-indigo-900/60 text-indigo-300",
        [OrderState.DELIVERED]: "bg-emerald-900/60 text-emerald-300",
        [OrderState.FINALIZED]: "bg-green-900/60 text-green-300",
        [OrderState.DISPUTED]: "bg-red-900/60 text-red-300",
    };
    return (_jsx("span", { className: cn("rounded-full px-2 py-0.5 text-[11px] font-medium", colors[state]), children: ORDER_STATE_LABELS[state] }));
}
function toBigInt(order) {
    try {
        return BigInt(order.total_token);
    }
    catch {
        return BigInt(Math.round(order.total_usd * 1e18));
    }
}
function deriveMetrics(orders) {
    let totalRevenueToken = BigInt(0);
    let pendingPayoutToken = BigInt(0);
    let activeEscrows = 0;
    let disputeCount = 0;
    let fulfillmentHoursTotal = 0;
    let fulfillmentSamples = 0;
    for (const order of orders) {
        const orderToken = toBigInt(order);
        totalRevenueToken += orderToken;
        if ([OrderState.INITIATED, OrderState.ESCROWED, OrderState.LABEL_CREATED, OrderState.SHIPPED, OrderState.IN_TRANSIT].includes(order.state)) {
            activeEscrows++;
        }
        if (order.state === OrderState.DISPUTED)
            disputeCount++;
        const releasedBps = order.payout_schedule.reduce((s, p) => p.releasedAt ? s + p.percentageBps : s, 0);
        pendingPayoutToken += (orderToken * BigInt(Math.max(0, 10000 - releasedBps))) / BigInt(10000);
        const shipped = order.state_history.find((t) => t.to === OrderState.SHIPPED);
        if (shipped) {
            const diff = Date.parse(shipped.timestamp) - Date.parse(order.created_at);
            if (diff > 0) {
                fulfillmentHoursTotal += diff / 3600000;
                fulfillmentSamples++;
            }
        }
    }
    return {
        total_orders: orders.length,
        total_revenue_usd: orders.reduce((s, o) => s + o.total_usd, 0),
        total_revenue_token: totalRevenueToken.toString(),
        fulfillment_avg_hours: fulfillmentSamples > 0 ? fulfillmentHoursTotal / fulfillmentSamples : 0,
        dispute_rate: orders.length > 0 ? disputeCount / orders.length : 0,
        active_escrows: activeEscrows,
        pending_payouts_token: pendingPayoutToken.toString(),
    };
}
function derivePayouts(orders) {
    const records = [];
    for (const order of orders) {
        const orderToken = toBigInt(order);
        order.payout_schedule.forEach((p, i) => {
            if (!p.releasedAt && !p.txHash)
                return;
            records.push({
                id: `${order.id}-${p.state}-${i}`,
                order_id: order.id,
                state: p.state,
                amount_token: p.amountToken ?? ((orderToken * BigInt(p.percentageBps)) / BigInt(10000)).toString(),
                amount_usd: (order.total_usd * p.percentageBps) / 10000,
                tx_hash: p.txHash ?? `pending-${order.id}`,
                timestamp: p.releasedAt ?? order.updated_at,
            });
        });
    }
    return records.sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp));
}
export function SellerDashboard({ sellerId, onConfirmLabel, onRespondDispute, className }) {
    const { apiClient } = useFlowState();
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [activeTab, setActiveTab] = useState("orders");
    const [activeFilter, setActiveFilter] = useState("all");
    const [advancingOrder, setAdvancingOrder] = useState(null);
    const loadOrders = useCallback(async () => {
        if (!apiClient) {
            setError("API client not configured");
            setLoading(false);
            return;
        }
        try {
            setLoading(true);
            const result = await apiClient.getSellerOrders(sellerId);
            setOrders(result.orders);
            setError(null);
        }
        catch (e) {
            setError(e instanceof Error ? e.message : "Failed to load orders");
        }
        finally {
            setLoading(false);
        }
    }, [apiClient, sellerId]);
    useEffect(() => { loadOrders(); }, [loadOrders]);
    async function handleConfirmLabel(order) {
        if (!apiClient)
            return;
        setAdvancingOrder(order.id);
        try {
            if (order.state === OrderState.ESCROWED) {
                await apiClient.confirmLabelPrinted(order.id, { seller_wallet: "" });
                onConfirmLabel?.(order.id);
            }
            await loadOrders();
        }
        catch (e) {
            console.error("Failed to advance order:", e);
        }
        finally {
            setAdvancingOrder(null);
        }
    }
    const filteredOrders = useMemo(() => orders.filter((o) => {
        if (activeFilter === "needs_action")
            return o.state === OrderState.ESCROWED || o.state === OrderState.LABEL_CREATED;
        if (activeFilter === "in_transit")
            return o.state === OrderState.SHIPPED || o.state === OrderState.IN_TRANSIT;
        if (activeFilter === "completed")
            return o.state === OrderState.DELIVERED || o.state === OrderState.FINALIZED;
        return true;
    }), [orders, activeFilter]);
    const metrics = useMemo(() => deriveMetrics(orders), [orders]);
    const payouts = useMemo(() => derivePayouts(orders), [orders]);
    const tabs = [
        { key: "orders", label: "Orders" },
        { key: "payouts", label: "Payouts" },
        { key: "metrics", label: "Metrics" },
        { key: "chat", label: "Seller Agent" },
    ];
    return (_jsxs("div", { className: cn("mx-auto max-w-7xl space-y-6", className), children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("h2", { className: "text-2xl font-bold text-neutral-100", children: "Seller Dashboard" }), _jsxs("p", { className: "text-sm text-neutral-400", children: ["Seller ID: ", sellerId] })] }), _jsx("button", { onClick: loadOrders, className: "rounded-lg border border-neutral-700 px-3 py-1.5 text-sm text-neutral-300 hover:bg-neutral-800 transition-colors", children: "Refresh" })] }), _jsx("div", { className: "flex gap-1 rounded-xl border border-neutral-800 bg-neutral-900 p-1", children: tabs.map((tab) => (_jsx("button", { onClick: () => setActiveTab(tab.key), className: cn("flex-1 rounded-lg px-3 py-1.5 text-sm font-medium transition-colors", activeTab === tab.key
                        ? "bg-neutral-800 text-neutral-100"
                        : "text-neutral-500 hover:text-neutral-300"), children: tab.label }, tab.key))) }), loading && (_jsx("div", { className: "flex items-center justify-center py-12", children: _jsx(Loader2, { className: "h-8 w-8 animate-spin text-neutral-500" }) })), error && !loading && (_jsx("div", { className: "rounded-xl border border-red-800 bg-red-950/40 p-4 text-sm text-red-300", children: error })), !loading && !error && (_jsxs(_Fragment, { children: [activeTab === "orders" && (_jsxs("div", { className: "space-y-3", children: [_jsx("div", { className: "flex flex-wrap gap-2", children: FILTERS.map((f) => (_jsx("button", { onClick: () => setActiveFilter(f.key), className: cn("rounded-lg px-3 py-1.5 text-sm font-medium transition-colors", activeFilter === f.key
                                        ? "bg-violet-600 text-white"
                                        : "border border-neutral-700 text-neutral-400 hover:text-neutral-200"), children: f.label }, f.key))) }), filteredOrders.length === 0 ? (_jsxs("div", { className: "flex flex-col items-center justify-center py-16 text-neutral-500", children: [_jsx(Package, { className: "mb-3 h-10 w-10 opacity-40" }), _jsx("p", { className: "text-sm", children: "No orders match this filter." })] })) : (filteredOrders.map((order) => {
                                const nextState = NEXT_STATES[order.state];
                                const actionLabel = ACTION_LABELS[order.state];
                                const isAdvancing = advancingOrder === order.id;
                                return (_jsx("div", { className: "rounded-xl border border-neutral-800 bg-neutral-900 p-4", children: _jsxs("div", { className: "flex items-start justify-between gap-4", children: [_jsxs("div", { className: "min-w-0 flex-1", children: [_jsxs("div", { className: "mb-1 flex items-center gap-2 flex-wrap", children: [_jsx("span", { className: "font-mono text-xs text-neutral-400", children: order.id }), _jsx(StateBadge, { state: order.state })] }), _jsx("p", { className: "text-sm text-neutral-300", children: order.items.map((i) => i.product_name).join(", ") }), _jsxs("div", { className: "mt-1 flex items-center gap-3 text-xs text-neutral-500", children: [_jsx("span", { children: formatDate(order.created_at) }), _jsx("span", { children: formatUsd(order.total_usd) }), order.tracking_number && (_jsxs("span", { className: "font-mono", children: [order.carrier, " | ", order.tracking_number.slice(0, 12), "..."] }))] }), _jsx(EscrowProgressBar, { className: "mt-3", state: order.state, payoutSchedule: order.payout_schedule, compact: true, isDisputed: order.state === OrderState.DISPUTED })] }), _jsxs("div", { className: "flex shrink-0 items-center gap-2", children: [order.label_url && (_jsx("a", { href: order.label_url, target: "_blank", rel: "noopener noreferrer", children: _jsxs("button", { className: "flex items-center gap-1.5 rounded-lg border border-neutral-700 px-2.5 py-1.5 text-xs text-neutral-300 hover:bg-neutral-800 transition-colors", children: [_jsx(Download, { className: "h-3.5 w-3.5" }), "Label"] }) })), nextState && actionLabel && (_jsxs("button", { onClick: () => handleConfirmLabel(order), disabled: isAdvancing, className: "flex items-center gap-1.5 rounded-lg bg-violet-600 px-2.5 py-1.5 text-xs text-white hover:bg-violet-500 disabled:opacity-50 transition-colors", children: [isAdvancing ? (_jsx(Loader2, { className: "h-3.5 w-3.5 animate-spin" })) : (_jsx(CheckCircle, { className: "h-3.5 w-3.5" })), actionLabel] }))] })] }) }, order.id));
                            }))] })), activeTab === "payouts" && (_jsxs("div", { className: "rounded-xl border border-neutral-800 bg-neutral-900 p-4", children: [_jsx("h3", { className: "mb-4 text-base font-semibold text-neutral-100", children: "Payout History" }), payouts.length === 0 ? (_jsx("p", { className: "text-sm text-neutral-500", children: "No payout releases yet." })) : (_jsx("div", { className: "divide-y divide-neutral-800", children: payouts.map((payout) => (_jsxs("div", { className: "flex items-center justify-between py-3", children: [_jsxs("div", { children: [_jsxs("p", { className: "text-sm font-medium text-neutral-200", children: [payout.state.replace(/_/g, " "), " \u00B7 Order ", payout.order_id.slice(0, 8)] }), _jsx("p", { className: "text-xs text-neutral-500", children: formatDateTime(payout.timestamp) })] }), _jsxs("div", { className: "text-right", children: [_jsxs("p", { className: "text-sm font-semibold text-emerald-400", children: ["+", formatUsd(payout.amount_usd)] }), _jsxs("a", { href: `${XRPL_EXPLORER}/tx/${payout.tx_hash}`, target: "_blank", rel: "noopener noreferrer", className: "flex items-center justify-end gap-0.5 text-xs text-neutral-500 hover:text-neutral-300", children: ["tx ", _jsx(ExternalLink, { className: "h-3 w-3" })] })] })] }, payout.id))) }))] })), activeTab === "metrics" && (_jsx("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3", children: [
                            { icon: Package, label: "Total Orders", value: metrics.total_orders.toString(), sub: `${metrics.active_escrows} in progress`, color: "text-violet-400" },
                            { icon: DollarSign, label: "Total Revenue", value: formatUsd(metrics.total_revenue_usd), sub: `${formatUsd(Number(metrics.pending_payouts_token) / 1e18)} pending`, color: "text-emerald-400" },
                            { icon: Clock, label: "Avg Fulfillment", value: `${metrics.fulfillment_avg_hours.toFixed(1)}h`, sub: "order to shipped", color: "text-blue-400" },
                            { icon: AlertTriangle, label: "Dispute Rate", value: `${(metrics.dispute_rate * 100).toFixed(1)}%`, sub: "of total orders", color: "text-amber-400" },
                            { icon: TrendingUp, label: "Active Escrows", value: metrics.active_escrows.toString(), sub: "awaiting fulfillment", color: "text-violet-400" },
                        ].map(({ icon: Icon, label, value, sub, color }) => (_jsxs("div", { className: "rounded-xl border border-neutral-800 bg-neutral-900 p-5", children: [_jsxs("div", { className: "mb-3 flex items-center gap-3", children: [_jsx("div", { className: "flex h-8 w-8 items-center justify-center rounded-lg bg-neutral-800", children: _jsx(Icon, { className: cn("h-4 w-4", color) }) }), _jsx("p", { className: "text-sm text-neutral-400", children: label })] }), _jsx("p", { className: "text-2xl font-bold text-neutral-100", children: value }), _jsx("p", { className: "mt-1 text-xs text-neutral-500", children: sub })] }, label))) })), activeTab === "chat" && (_jsx(AgentChat, { role: "seller", userId: sellerId, variant: "panel", className: "h-[32rem]", placeholder: "Ask about your orders, payouts, or metrics..." }))] }))] }));
}
//# sourceMappingURL=SellerDashboard.js.map