"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { Zap, X, ChevronRight, Loader2, CheckCircle, MapPin, Truck } from "lucide-react";
import { useFlowState } from "./FlowStateProvider";
import { clsx } from "clsx";
function cn(...args) {
    return clsx(...args);
}
const EMPTY_ADDRESS = {
    name: "",
    address1: "",
    address2: "",
    city: "",
    state: "",
    zip: "",
    country: "US",
};
export function PayButton({ items, sellerId, sellerWallet, addressFrom, onSuccess, onError, disabled, className, label = "Pay with FlowState", }) {
    const { apiClient } = useFlowState();
    const [open, setOpen] = useState(false);
    const [step, setStep] = useState("address");
    const [address, setAddress] = useState(EMPTY_ADDRESS);
    const [shippingOptions, setShippingOptions] = useState([]);
    const [selectedRate, setSelectedRate] = useState(null);
    const [orderId, setOrderId] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    function reset() {
        setStep("address");
        setAddress(EMPTY_ADDRESS);
        setShippingOptions([]);
        setSelectedRate(null);
        setOrderId(null);
        setError(null);
    }
    function close() {
        setOpen(false);
        reset();
    }
    const subtotal = items.reduce((s, i) => s + i.quantity * i.unitPriceUsd, 0);
    async function handleAddressSubmit(e) {
        e.preventDefault();
        if (!apiClient) {
            setError("API client not configured");
            return;
        }
        setLoading(true);
        setError(null);
        try {
            const result = await apiClient.createOrder({
                seller_id: sellerId,
                buyer_wallet: "",
                seller_wallet: sellerWallet,
                address_from: {
                    name: addressFrom.name,
                    street1: addressFrom.street1,
                    city: addressFrom.city,
                    state: addressFrom.state,
                    zip: addressFrom.zip,
                    country: addressFrom.country,
                },
                address_to: {
                    name: address.name,
                    street1: address.address1,
                    street2: address.address2,
                    city: address.city,
                    state: address.state,
                    zip: address.zip,
                    country: address.country,
                },
                parcel: {
                    length: 10,
                    width: 8,
                    height: 4,
                    distanceUnit: "in",
                    weight: items.reduce((s, i) => s + (i.weightOz ?? 8) * i.quantity, 0),
                    massUnit: "oz",
                },
                items: items.map((i) => ({
                    externalItemId: i.externalItemId,
                    name: i.name,
                    quantity: i.quantity,
                    unitPriceUsd: i.unitPriceUsd,
                    weightOz: i.weightOz,
                })),
            });
            setOrderId(result.order_id);
            setShippingOptions(result.shipping_options);
            setStep("shipping");
        }
        catch (err) {
            setError(err instanceof Error ? err.message : "Failed to get shipping rates");
        }
        finally {
            setLoading(false);
        }
    }
    async function handleShippingSelect() {
        if (!apiClient || !orderId || !selectedRate)
            return;
        setLoading(true);
        setError(null);
        try {
            await apiClient.selectShipping(orderId, { rate_id: selectedRate.id });
            setStep("review");
        }
        catch (err) {
            setError(err instanceof Error ? err.message : "Failed to select shipping");
        }
        finally {
            setLoading(false);
        }
    }
    async function handleConfirmPayment() {
        if (!apiClient || !orderId)
            return;
        setLoading(true);
        setStep("processing");
        setError(null);
        try {
            // In a full implementation, this would trigger wallet approval and escrow deposit
            // For now, confirm escrow with a placeholder tx hash
            await apiClient.confirmEscrow(orderId, { tx_hash: `0x${orderId.replace(/-/g, "")}` });
            setStep("success");
            onSuccess?.(orderId);
        }
        catch (err) {
            const e = err instanceof Error ? err : new Error("Payment failed");
            setError(e.message);
            setStep("review");
            onError?.(e);
        }
        finally {
            setLoading(false);
        }
    }
    return (_jsxs(_Fragment, { children: [_jsxs("button", { onClick: () => setOpen(true), disabled: disabled || !apiClient, className: cn("flex items-center gap-2 rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white hover:bg-violet-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors", className), children: [_jsx(Zap, { className: "h-4 w-4" }), label] }), open && (_jsxs("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4", children: [_jsx("div", { className: "absolute inset-0 bg-black/70 backdrop-blur-sm", onClick: close }), _jsxs("div", { className: "relative w-full max-w-md rounded-2xl border border-neutral-800 bg-neutral-900 shadow-2xl", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-neutral-800 px-5 py-4", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Zap, { className: "h-4 w-4 text-violet-400" }), _jsx("span", { className: "font-semibold text-neutral-100", children: "FlowState Checkout" })] }), _jsx("button", { onClick: close, className: "text-neutral-500 hover:text-neutral-300", children: _jsx(X, { className: "h-5 w-5" }) })] }), step !== "success" && (_jsx("div", { className: "flex items-center gap-1.5 px-5 py-3 border-b border-neutral-800", children: ["address", "shipping", "review"].map((s, i) => (_jsxs("div", { className: "flex items-center gap-1.5", children: [_jsx("div", { className: cn("flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold", (step === s || (step === "processing" && s === "review"))
                                                ? "bg-violet-600 text-white"
                                                : ["processing", "review", "shipping"].indexOf(step) > i
                                                    ? "bg-emerald-600 text-white"
                                                    : "bg-neutral-800 text-neutral-500"), children: i + 1 }), _jsx("span", { className: cn("text-xs", step === s ? "text-neutral-200" : "text-neutral-500"), children: s.charAt(0).toUpperCase() + s.slice(1) }), i < 2 && _jsx(ChevronRight, { className: "h-3 w-3 text-neutral-600" })] }, s))) })), _jsxs("div", { className: "p-5", children: [error && (_jsx("div", { className: "mb-4 rounded-lg border border-red-800 bg-red-950/40 p-3 text-sm text-red-300", children: error })), step === "address" && (_jsxs("form", { onSubmit: handleAddressSubmit, className: "space-y-3", children: [_jsxs("div", { className: "flex items-center gap-2 mb-4", children: [_jsx(MapPin, { className: "h-4 w-4 text-violet-400" }), _jsx("h3", { className: "font-medium text-neutral-200", children: "Shipping Address" })] }), [
                                                { field: "name", label: "Full Name", required: true },
                                                { field: "address1", label: "Street Address", required: true },
                                                { field: "address2", label: "Apt, Suite (optional)", required: false },
                                                { field: "city", label: "City", required: true },
                                                { field: "state", label: "State", required: true },
                                                { field: "zip", label: "ZIP Code", required: true },
                                            ].map(({ field, label, required }) => (_jsxs("div", { children: [_jsx("label", { className: "mb-1 block text-xs text-neutral-400", children: label }), _jsx("input", { required: required, value: address[field] ?? "", onChange: (e) => setAddress((prev) => ({ ...prev, [field]: e.target.value })), className: "w-full rounded-lg border border-neutral-700 bg-neutral-800 px-3 py-2 text-sm text-neutral-200 outline-none focus:border-violet-500/50" })] }, field))), _jsxs("button", { type: "submit", disabled: loading, className: "mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-violet-600 py-3 text-sm font-semibold text-white hover:bg-violet-500 disabled:opacity-50 transition-colors", children: [loading ? _jsx(Loader2, { className: "h-4 w-4 animate-spin" }) : null, "Get Shipping Rates"] })] })), step === "shipping" && (_jsxs("div", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-center gap-2 mb-4", children: [_jsx(Truck, { className: "h-4 w-4 text-violet-400" }), _jsx("h3", { className: "font-medium text-neutral-200", children: "Select Shipping" })] }), shippingOptions.length === 0 ? (_jsx("p", { className: "text-sm text-neutral-500", children: "No shipping options available." })) : (shippingOptions.map((opt) => (_jsx("button", { onClick: () => setSelectedRate(opt), className: cn("w-full rounded-xl border p-3 text-left transition-colors", selectedRate?.id === opt.id
                                                    ? "border-violet-500 bg-violet-500/10"
                                                    : "border-neutral-700 hover:border-neutral-600 bg-neutral-800"), children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsxs("p", { className: "text-sm font-medium text-neutral-200", children: [opt.carrier, " ", opt.service] }), _jsxs("p", { className: "text-xs text-neutral-500", children: [opt.estimated_days, " days"] })] }), _jsxs("span", { className: "text-sm font-semibold text-neutral-100", children: ["$", opt.price_usd.toFixed(2)] })] }) }, opt.id)))), _jsxs("button", { onClick: handleShippingSelect, disabled: !selectedRate || loading, className: "mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-violet-600 py-3 text-sm font-semibold text-white hover:bg-violet-500 disabled:opacity-50 transition-colors", children: [loading ? _jsx(Loader2, { className: "h-4 w-4 animate-spin" }) : null, "Continue to Review"] })] })), step === "review" && (_jsxs("div", { className: "space-y-4", children: [_jsx("h3", { className: "font-medium text-neutral-200", children: "Review Order" }), _jsxs("div", { className: "rounded-xl border border-neutral-800 bg-neutral-800/50 p-3 space-y-2", children: [items.map((item, i) => (_jsxs("div", { className: "flex items-center justify-between text-sm", children: [_jsxs("span", { className: "text-neutral-300", children: [item.name, " \u00D7 ", item.quantity] }), _jsxs("span", { className: "text-neutral-400", children: ["$", (item.quantity * item.unitPriceUsd).toFixed(2)] })] }, i))), selectedRate && (_jsxs("div", { className: "flex items-center justify-between text-sm border-t border-neutral-700 pt-2", children: [_jsxs("span", { className: "text-neutral-300", children: ["Shipping (", selectedRate.carrier, ")"] }), _jsxs("span", { className: "text-neutral-400", children: ["$", selectedRate.price_usd.toFixed(2)] })] })), _jsxs("div", { className: "flex items-center justify-between text-sm border-t border-neutral-700 pt-2 font-semibold", children: [_jsx("span", { className: "text-neutral-200", children: "Total" }), _jsxs("span", { className: "text-neutral-100", children: ["$", (subtotal + (selectedRate?.price_usd ?? 0)).toFixed(2)] })] })] }), _jsx("p", { className: "text-xs text-neutral-500", children: "Funds will be held in escrow and released to the seller as your order progresses." }), _jsxs("button", { onClick: handleConfirmPayment, disabled: loading, className: "flex w-full items-center justify-center gap-2 rounded-xl bg-violet-600 py-3 text-sm font-semibold text-white hover:bg-violet-500 disabled:opacity-50 transition-colors", children: [loading ? _jsx(Loader2, { className: "h-4 w-4 animate-spin" }) : _jsx(Zap, { className: "h-4 w-4" }), "Confirm & Deposit Escrow"] })] })), step === "processing" && (_jsxs("div", { className: "flex flex-col items-center gap-4 py-8", children: [_jsx(Loader2, { className: "h-10 w-10 animate-spin text-violet-400" }), _jsx("p", { className: "text-sm font-medium text-neutral-200", children: "Processing Payment..." }), _jsx("p", { className: "text-xs text-neutral-500", children: "Please approve the transaction in your wallet" })] })), step === "success" && (_jsxs("div", { className: "flex flex-col items-center gap-4 py-8 text-center", children: [_jsx(CheckCircle, { className: "h-12 w-12 text-emerald-400" }), _jsxs("div", { children: [_jsx("p", { className: "font-semibold text-neutral-100", children: "Payment Successful!" }), _jsx("p", { className: "mt-1 text-sm text-neutral-400", children: "Your funds are secured in escrow. Track your order progress." })] }), orderId && (_jsxs("p", { className: "text-xs font-mono text-neutral-500", children: ["Order: ", orderId] })), _jsx("button", { onClick: close, className: "rounded-xl bg-violet-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-violet-500 transition-colors", children: "Done" })] }))] })] })] }))] }));
}
//# sourceMappingURL=PayButton.js.map