import { type Order } from "./types/index";
export interface OrderTrackerProps {
    order: Order;
    explorerUrl?: string;
}
export declare function OrderTracker({ order, explorerUrl }: OrderTrackerProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=OrderTracker.d.ts.map