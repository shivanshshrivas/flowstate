"use client";
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Loader2 } from "lucide-react";
import { useFlowState } from "./FlowStateProvider";
import { clsx } from "clsx";
function cn(...args) {
    return clsx(...args);
}
export function AgentChat({ role, userId, variant = "inline", className, placeholder = "Ask me anything...", }) {
    const { apiClient } = useFlowState();
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState("");
    const [loading, setLoading] = useState(false);
    const [sessionId] = useState(() => `session-${Date.now()}`);
    const [suggestedActions, setSuggestedActions] = useState([]);
    const bottomRef = useRef(null);
    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, loading]);
    async function sendMessage(text) {
        if (!text.trim() || loading)
            return;
        const userMsg = {
            id: `msg-${Date.now()}`,
            role: "user",
            content: text.trim(),
            timestamp: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, userMsg]);
        setInput("");
        setSuggestedActions([]);
        setLoading(true);
        try {
            if (!apiClient) {
                throw new Error("API client not configured. Set baseUrl in FlowStateProvider config.");
            }
            const response = await apiClient.chatWithAgent({
                role,
                user_id: userId,
                message: text.trim(),
                session_id: sessionId,
            });
            const assistantMsg = {
                id: `msg-${Date.now()}-ai`,
                role: "assistant",
                content: response.message,
                timestamp: new Date().toISOString(),
            };
            setMessages((prev) => [...prev, assistantMsg]);
            if (response.suggested_actions) {
                setSuggestedActions(response.suggested_actions);
            }
        }
        catch (err) {
            const errorMsg = {
                id: `msg-${Date.now()}-err`,
                role: "assistant",
                content: `Sorry, I encountered an error: ${err instanceof Error ? err.message : "Unknown error"}`,
                timestamp: new Date().toISOString(),
            };
            setMessages((prev) => [...prev, errorMsg]);
        }
        finally {
            setLoading(false);
        }
    }
    const containerClass = cn("flex flex-col bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden", variant === "panel" && "h-full", variant === "inline" && "h-[28rem]", variant === "floating" && "h-[24rem] w-80 shadow-2xl", className);
    return (_jsxs("div", { className: containerClass, children: [_jsxs("div", { className: "flex items-center gap-2 border-b border-neutral-800 px-4 py-3", children: [_jsx(Bot, { className: "h-4 w-4 text-violet-400" }), _jsxs("span", { className: "text-sm font-medium text-neutral-200 capitalize", children: [role, " Agent"] }), _jsx("span", { className: "ml-auto h-2 w-2 rounded-full bg-emerald-400", title: "Online" })] }), _jsxs("div", { className: "flex-1 overflow-y-auto p-4 space-y-3", children: [messages.length === 0 && (_jsxs("p", { className: "text-xs text-neutral-500 text-center mt-4", children: ["Hi! I'm your ", role, " assistant. How can I help?"] })), messages.map((msg) => (_jsxs("div", { className: cn("flex gap-2 max-w-[90%]", msg.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"), children: [_jsx("div", { className: cn("flex h-6 w-6 shrink-0 items-center justify-center rounded-full mt-0.5", msg.role === "user"
                                    ? "bg-violet-600"
                                    : "bg-neutral-700"), children: msg.role === "user" ? (_jsx(User, { className: "h-3.5 w-3.5 text-white" })) : (_jsx(Bot, { className: "h-3.5 w-3.5 text-neutral-300" })) }), _jsx("div", { className: cn("rounded-xl px-3 py-2 text-sm leading-relaxed", msg.role === "user"
                                    ? "bg-violet-600 text-white"
                                    : "bg-neutral-800 text-neutral-200"), children: msg.content })] }, msg.id))), loading && (_jsxs("div", { className: "flex gap-2 mr-auto", children: [_jsx("div", { className: "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-neutral-700 mt-0.5", children: _jsx(Bot, { className: "h-3.5 w-3.5 text-neutral-300" }) }), _jsx("div", { className: "rounded-xl bg-neutral-800 px-3 py-2", children: _jsx(Loader2, { className: "h-4 w-4 text-neutral-400 animate-spin" }) })] })), _jsx("div", { ref: bottomRef })] }), suggestedActions.length > 0 && (_jsx("div", { className: "flex flex-wrap gap-1.5 px-4 pb-2", children: suggestedActions.map((action, i) => (_jsx("button", { onClick: () => sendMessage(action.label), className: "rounded-full border border-violet-500/40 bg-violet-500/10 px-2.5 py-1 text-xs text-violet-300 hover:bg-violet-500/20 transition-colors", children: action.label }, i))) })), _jsx("div", { className: "border-t border-neutral-800 p-3", children: _jsxs("div", { className: "flex gap-2", children: [_jsx("input", { value: input, onChange: (e) => setInput(e.target.value), onKeyDown: (e) => {
                                if (e.key === "Enter" && !e.shiftKey) {
                                    e.preventDefault();
                                    sendMessage(input);
                                }
                            }, placeholder: placeholder, disabled: loading, className: "flex-1 rounded-lg bg-neutral-800 px-3 py-2 text-sm text-neutral-200 placeholder:text-neutral-500 outline-none border border-neutral-700 focus:border-violet-500/50 disabled:opacity-50" }), _jsx("button", { onClick: () => sendMessage(input), disabled: !input.trim() || loading, className: "flex h-9 w-9 items-center justify-center rounded-lg bg-violet-600 text-white hover:bg-violet-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors", children: _jsx(Send, { className: "h-4 w-4" }) })] }) })] }));
}
//# sourceMappingURL=AgentChat.js.map