import { type PayoutSchedule, OrderState } from "./types/index";
export interface EscrowProgressBarProps {
    state: OrderState;
    payoutSchedule?: PayoutSchedule[];
    isDisputed?: boolean;
    compact?: boolean;
    className?: string;
}
export declare function EscrowProgressBar({ state, payoutSchedule, isDisputed, compact, className, }: EscrowProgressBarProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=EscrowProgressBar.d.ts.map