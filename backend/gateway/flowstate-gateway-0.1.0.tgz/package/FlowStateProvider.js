"use client";
import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext, useMemo } from "react";
import { FlowStateApiClient } from "./apiClient";
import { FlowStateWsClient } from "./wsClient";
const DEFAULT_CONTRACT_ADDRESSES = {
    escrowStateMachine: "0x0000000000000000000000000000000000000000",
    disputeResolver: "0x0000000000000000000000000000000000000000",
    paymentSplitter: "0x0000000000000000000000000000000000000000",
    mockRLUSD: "0x0000000000000000000000000000000000000000",
};
const FlowStateContext = createContext(null);
export function FlowStateProvider({ config, contractAddresses, children, }) {
    const contracts = {
        escrowStateMachine: config.contracts?.escrowStateMachine ??
            contractAddresses?.escrowStateMachine ??
            DEFAULT_CONTRACT_ADDRESSES.escrowStateMachine,
        disputeResolver: config.contracts?.disputeResolver ??
            contractAddresses?.disputeResolver ??
            DEFAULT_CONTRACT_ADDRESSES.disputeResolver,
        paymentSplitter: config.contracts?.paymentSplitter ??
            contractAddresses?.paymentSplitter ??
            DEFAULT_CONTRACT_ADDRESSES.paymentSplitter,
        mockRLUSD: config.contracts?.mockRLUSD ??
            contractAddresses?.mockRLUSD ??
            DEFAULT_CONTRACT_ADDRESSES.mockRLUSD,
    };
    const apiClient = useMemo(() => {
        if (!config.baseUrl)
            return null;
        return new FlowStateApiClient({ baseUrl: config.baseUrl, apiKey: config.apiKey });
    }, [config.baseUrl, config.apiKey]);
    const wsClient = useMemo(() => {
        if (!config.baseUrl)
            return null;
        return new FlowStateWsClient({ baseUrl: config.baseUrl, apiKey: config.apiKey });
    }, [config.baseUrl, config.apiKey]);
    return (_jsx(FlowStateContext.Provider, { value: { config, contracts, apiClient, wsClient }, children: children }));
}
export function useFlowState() {
    const ctx = useContext(FlowStateContext);
    if (!ctx)
        throw new Error("useFlowState must be used inside FlowStateProvider");
    return ctx;
}
//# sourceMappingURL=FlowStateProvider.js.map