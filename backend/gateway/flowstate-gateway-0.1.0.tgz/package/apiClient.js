export class FlowStateApiClient {
    constructor({ baseUrl, apiKey }) {
        this.baseUrl = baseUrl.replace(/\/$/, "");
        this.apiKey = apiKey;
    }
    async request(method, path, body) {
        const res = await fetch(`${this.baseUrl}${path}`, {
            method,
            headers: {
                Authorization: `Bearer ${this.apiKey}`,
                "Content-Type": "application/json",
            },
            body: body !== undefined ? JSON.stringify(body) : undefined,
        });
        const json = await res.json();
        if (!res.ok || !json.success) {
            throw new Error(json.error?.message ??
                `FlowState API error ${res.status} on ${method} ${path}`);
        }
        return json.data;
    }
    // ─── Orders ─────────────────────────────────────────────────────────────
    async createOrder(input) {
        return this.request("POST", "/api/v1/orders/create", input);
    }
    async selectShipping(orderId, input) {
        return this.request("POST", `/api/v1/orders/${orderId}/select-shipping`, input);
    }
    async confirmEscrow(orderId, input) {
        return this.request("POST", `/api/v1/orders/${orderId}/confirm-escrow`, input);
    }
    async confirmLabelPrinted(orderId, input) {
        return this.request("POST", `/api/v1/orders/${orderId}/confirm-label-printed`, input);
    }
    async finalizeOrder(orderId) {
        return this.request("POST", `/api/v1/orders/${orderId}/finalize`);
    }
    async getOrder(orderId) {
        return this.request("GET", `/api/v1/orders/${orderId}`);
    }
    async listOrders(filters) {
        const params = new URLSearchParams();
        if (filters) {
            Object.entries(filters).forEach(([k, v]) => {
                if (v !== undefined)
                    params.set(k, String(v));
            });
        }
        const qs = params.toString() ? `?${params.toString()}` : "";
        return this.request("GET", `/api/v1/orders${qs}`);
    }
    // ─── Shipping ─────────────────────────────────────────────────────────────
    async getShippingRates(params) {
        return this.request("GET", `/api/v1/shipping/rates`);
    }
    async trackShipment(orderId) {
        return this.request("GET", `/api/v1/shipping/track/${orderId}`);
    }
    // ─── Sellers ─────────────────────────────────────────────────────────────
    async onboardSeller(input) {
        return this.request("POST", "/api/v1/sellers/onboard", input);
    }
    async getSellerOrders(sellerId, filters) {
        const params = new URLSearchParams();
        if (filters) {
            Object.entries(filters).forEach(([k, v]) => {
                if (v !== undefined)
                    params.set(k, String(v));
            });
        }
        const qs = params.toString() ? `?${params.toString()}` : "";
        return this.request("GET", `/api/v1/sellers/${sellerId}/orders${qs}`);
    }
    async getSellerMetrics(sellerId) {
        return this.request("GET", `/api/v1/sellers/${sellerId}/metrics`);
    }
    async getSellerPayouts(sellerId) {
        return this.request("GET", `/api/v1/sellers/${sellerId}/payouts`);
    }
    // ─── Disputes ─────────────────────────────────────────────────────────────
    async createDispute(input) {
        return this.request("POST", "/api/v1/disputes/create", input);
    }
    async respondToDispute(disputeId, input) {
        return this.request("POST", `/api/v1/disputes/${disputeId}/respond`, input);
    }
    async resolveDispute(disputeId, input) {
        return this.request("POST", `/api/v1/disputes/${disputeId}/resolve`, input);
    }
    // ─── Platform ─────────────────────────────────────────────────────────────
    async getPlatformAnalytics(projectId) {
        return this.request("GET", `/api/v1/platform/${projectId}/analytics`);
    }
    async getPlatformSellers(projectId) {
        return this.request("GET", `/api/v1/platform/${projectId}/sellers`);
    }
    async getGasCosts(projectId) {
        return this.request("GET", `/api/v1/platform/${projectId}/gas-costs`);
    }
    // ─── Webhooks ─────────────────────────────────────────────────────────────
    async registerWebhook(input) {
        return this.request("POST", "/api/v1/webhooks/register", input);
    }
    async getWebhookLogs(filters) {
        const params = new URLSearchParams();
        if (filters) {
            Object.entries(filters).forEach(([k, v]) => {
                if (v !== undefined)
                    params.set(k, String(v));
            });
        }
        const qs = params.toString() ? `?${params.toString()}` : "";
        return this.request("GET", `/api/v1/webhooks/logs${qs}`);
    }
    // ─── Agents ───────────────────────────────────────────────────────────────
    async chatWithAgent(input) {
        return this.request("POST", "/api/v1/agents/chat", input);
    }
    // ─── Auth ─────────────────────────────────────────────────────────────────
    async createProject(input) {
        return this.request("POST", "/api/v1/auth/projects/create", input);
    }
    async rotateApiKey(projectId) {
        return this.request("POST", "/api/v1/auth/api-keys/rotate", { project_id: projectId });
    }
}
//# sourceMappingURL=apiClient.js.map