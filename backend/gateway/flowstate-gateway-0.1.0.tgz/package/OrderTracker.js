"use client";
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { CheckCircle, Circle, AlertTriangle, ExternalLink } from "lucide-react";
import { OrderState, ORDER_STATE_LABELS, ORDER_STATE_SEQUENCE, } from "./types/index";
import { useFlowState } from "./FlowStateProvider";
import { clsx } from "clsx";
function cn(...args) {
    return clsx(...args);
}
function formatDateTime(iso) {
    return new Date(iso).toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
    });
}
function formatToken(raw) {
    const n = parseFloat(raw);
    if (isNaN(n))
        return raw;
    return n.toLocaleString(undefined, { maximumFractionDigits: 4 }) + " FLUSD";
}
export function OrderTracker({ order, explorerUrl = "https://explorer.testnet.xrplevm.org" }) {
    const { wsClient } = useFlowState();
    const [liveOrder, setLiveOrder] = useState(order);
    // Subscribe to real-time order state updates via wsClient
    useEffect(() => {
        if (!wsClient)
            return;
        wsClient.connect();
        const unsub = wsClient.on("order_state_changed", (data) => {
            if (data.order_id === liveOrder.id) {
                setLiveOrder((prev) => ({
                    ...prev,
                    state: data.new_state,
                }));
            }
        });
        return () => {
            unsub();
        };
    }, [wsClient, liveOrder.id]);
    // Keep in sync when prop changes
    useEffect(() => {
        setLiveOrder(order);
    }, [order]);
    const isDisputed = liveOrder.state === OrderState.DISPUTED;
    const currentIdx = ORDER_STATE_SEQUENCE.indexOf(liveOrder.state);
    return (_jsxs("div", { className: "space-y-6", children: [isDisputed && (_jsxs("div", { className: "flex items-center gap-3 rounded-xl border border-red-800 bg-red-950/40 p-4", children: [_jsx(AlertTriangle, { className: "h-5 w-5 text-red-400 shrink-0" }), _jsxs("div", { children: [_jsx("p", { className: "font-semibold text-red-300", children: "Order Disputed" }), _jsx("p", { className: "text-sm text-red-400", children: "Funds are frozen. The dispute is under review." })] })] })), _jsx("div", { className: "relative", children: ORDER_STATE_SEQUENCE.map((state, idx) => {
                    const transition = liveOrder.state_history.find((h) => h.to === state);
                    const payout = liveOrder.payout_schedule.find((p) => p.state === state);
                    const isPast = currentIdx > idx && !isDisputed;
                    const isCurrent = currentIdx === idx && !isDisputed;
                    return (_jsxs("div", { className: "flex gap-4", children: [_jsxs("div", { className: "flex flex-col items-center", children: [_jsx("div", { className: cn("flex h-8 w-8 items-center justify-center rounded-full border-2 shrink-0", isPast
                                            ? "border-emerald-500 bg-emerald-500"
                                            : isCurrent
                                                ? "border-violet-500 bg-violet-500"
                                                : "border-neutral-700 bg-neutral-900"), children: isPast ? (_jsx(CheckCircle, { className: "h-4 w-4 text-white" })) : (_jsx(Circle, { className: cn("h-4 w-4", isCurrent ? "text-white" : "text-neutral-600") })) }), idx < ORDER_STATE_SEQUENCE.length - 1 && (_jsx("div", { className: cn("w-0.5 flex-1 min-h-[2rem]", isPast ? "bg-emerald-500/50" : "bg-neutral-800") }))] }), _jsxs("div", { className: "pb-6 flex-1", children: [_jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [_jsx("span", { className: cn("font-medium text-sm", isPast
                                                    ? "text-emerald-400"
                                                    : isCurrent
                                                        ? "text-violet-400"
                                                        : "text-neutral-500"), children: ORDER_STATE_LABELS[state] }), isCurrent && !isDisputed && (_jsx("span", { className: "rounded-full border border-violet-500/30 bg-violet-500/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-violet-200", children: "Current" })), payout && (_jsxs("span", { className: "text-xs text-neutral-500", children: [(payout.percentageBps / 100).toFixed(0), "% payout"] }))] }), transition && (_jsxs("p", { className: "text-xs text-neutral-500 mt-0.5", children: [formatDateTime(transition.timestamp), transition.triggeredBy !== "buyer" &&
                                                ` · by ${transition.triggeredBy}`] })), payout?.releasedAt && (_jsxs("div", { className: "mt-1 flex items-center gap-2", children: [_jsxs("span", { className: "text-xs text-emerald-400", children: ["Paid: ", payout.amountToken ? formatToken(payout.amountToken) : "–"] }), payout.txHash && (_jsxs("a", { href: `${explorerUrl}/tx/${payout.txHash}`, target: "_blank", rel: "noopener noreferrer", className: "text-xs text-neutral-500 hover:text-neutral-300 flex items-center gap-0.5", children: [_jsx(ExternalLink, { className: "h-3 w-3" }), " tx"] }))] }))] })] }, state));
                }) })] }));
}
//# sourceMappingURL=OrderTracker.js.map