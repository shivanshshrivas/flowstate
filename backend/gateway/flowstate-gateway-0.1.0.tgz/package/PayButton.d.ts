export interface PayButtonProps {
    items: Array<{
        name: string;
        quantity: number;
        unitPriceUsd: number;
        weightOz?: number;
        externalItemId?: string;
    }>;
    sellerId: string;
    sellerWallet: string;
    addressFrom: {
        name: string;
        street1: string;
        city: string;
        state: string;
        zip: string;
        country: string;
    };
    onSuccess?: (orderId: string) => void;
    onError?: (error: Error) => void;
    disabled?: boolean;
    className?: string;
    label?: string;
}
export declare function PayButton({ items, sellerId, sellerWallet, addressFrom, onSuccess, onError, disabled, className, label, }: PayButtonProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=PayButton.d.ts.map