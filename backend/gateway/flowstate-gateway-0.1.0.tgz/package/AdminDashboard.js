"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState, useCallback } from "react";
import { AlertTriangle, BarChart3, Clock, DollarSign, Loader2, Package, Shield } from "lucide-react";
import { useFlowState } from "./FlowStateProvider";
import { AgentChat } from "./AgentChat";
import { OrderState, ORDER_STATE_LABELS, } from "./types/index";
import { clsx } from "clsx";
function cn(...args) {
    return clsx(...args);
}
function formatUsd(usd) {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(usd);
}
function formatDateTime(iso) {
    return new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
function StatusBadge({ state }) {
    const colors = {
        [OrderState.DISPUTED]: "bg-red-900/60 text-red-300",
        [OrderState.FINALIZED]: "bg-green-900/60 text-green-300",
        [OrderState.DELIVERED]: "bg-emerald-900/60 text-emerald-300",
        [OrderState.IN_TRANSIT]: "bg-indigo-900/60 text-indigo-300",
        [OrderState.ESCROWED]: "bg-violet-900/60 text-violet-300",
    };
    return (_jsx("span", { className: cn("rounded-full px-2 py-0.5 text-[11px] font-medium", colors[state] ?? "bg-neutral-700 text-neutral-300"), children: ORDER_STATE_LABELS[state] }));
}
export function AdminDashboard({ projectId, className }) {
    const { apiClient } = useFlowState();
    const [analytics, setAnalytics] = useState(null);
    const [sellers, setSellers] = useState([]);
    const [webhookLogs, setWebhookLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [activeTab, setActiveTab] = useState("analytics");
    const loadData = useCallback(async () => {
        if (!apiClient) {
            setError("API client not configured");
            setLoading(false);
            return;
        }
        try {
            setLoading(true);
            const [analyticsData, sellersData, logsData] = await Promise.all([
                apiClient.getPlatformAnalytics(projectId),
                apiClient.getPlatformSellers(projectId),
                apiClient.getWebhookLogs({ limit: 50 }),
            ]);
            setAnalytics(analyticsData);
            setSellers(sellersData.sellers);
            setWebhookLogs(logsData.logs);
            setError(null);
        }
        catch (e) {
            setError(e instanceof Error ? e.message : "Failed to load platform data");
        }
        finally {
            setLoading(false);
        }
    }, [apiClient, projectId]);
    useEffect(() => { loadData(); }, [loadData]);
    const tabs = [
        { key: "analytics", label: "Analytics" },
        { key: "sellers", label: "Sellers" },
        { key: "webhooks", label: "Webhooks" },
        { key: "chat", label: "Admin Agent" },
    ];
    return (_jsxs("div", { className: cn("mx-auto max-w-7xl space-y-6", className), children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("h2", { className: "text-2xl font-bold text-neutral-100", children: "Admin Dashboard" }), _jsxs("p", { className: "text-sm text-neutral-400", children: ["Project: ", projectId] })] }), _jsx("button", { onClick: loadData, className: "rounded-lg border border-neutral-700 px-3 py-1.5 text-sm text-neutral-300 hover:bg-neutral-800 transition-colors", children: "Refresh" })] }), _jsx("div", { className: "flex gap-1 rounded-xl border border-neutral-800 bg-neutral-900 p-1", children: tabs.map((tab) => (_jsx("button", { onClick: () => setActiveTab(tab.key), className: cn("flex-1 rounded-lg px-3 py-1.5 text-sm font-medium transition-colors", activeTab === tab.key
                        ? "bg-neutral-800 text-neutral-100"
                        : "text-neutral-500 hover:text-neutral-300"), children: tab.label }, tab.key))) }), loading && (_jsx("div", { className: "flex items-center justify-center py-12", children: _jsx(Loader2, { className: "h-8 w-8 animate-spin text-neutral-500" }) })), error && !loading && (_jsx("div", { className: "rounded-xl border border-red-800 bg-red-950/40 p-4 text-sm text-red-300", children: error })), !loading && !error && (_jsxs(_Fragment, { children: [activeTab === "analytics" && analytics && (_jsxs("div", { className: "space-y-6", children: [_jsx("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4", children: [
                                    { icon: Package, label: "Total Orders", value: analytics.total_orders.toString(), color: "text-violet-400" },
                                    { icon: DollarSign, label: "Total Volume", value: formatUsd(analytics.total_volume_usd), color: "text-emerald-400" },
                                    { icon: Shield, label: "Active Escrows", value: analytics.active_escrows.toString(), color: "text-blue-400" },
                                    { icon: AlertTriangle, label: "Dispute Rate", value: `${(analytics.dispute_rate * 100).toFixed(1)}%`, color: "text-amber-400" },
                                    { icon: Clock, label: "Avg Resolution", value: `${analytics.avg_resolution_hours.toFixed(1)}h`, color: "text-indigo-400" },
                                ].map(({ icon: Icon, label, value, color }) => (_jsxs("div", { className: "rounded-xl border border-neutral-800 bg-neutral-900 p-5", children: [_jsxs("div", { className: "mb-3 flex items-center gap-3", children: [_jsx("div", { className: "flex h-8 w-8 items-center justify-center rounded-lg bg-neutral-800", children: _jsx(Icon, { className: cn("h-4 w-4", color) }) }), _jsx("p", { className: "text-sm text-neutral-400", children: label })] }), _jsx("p", { className: "text-2xl font-bold text-neutral-100", children: value })] }, label))) }), analytics.orders_by_day.length > 0 && (_jsxs("div", { className: "rounded-xl border border-neutral-800 bg-neutral-900 p-5", children: [_jsxs("div", { className: "mb-4 flex items-center gap-2", children: [_jsx(BarChart3, { className: "h-4 w-4 text-neutral-400" }), _jsx("h3", { className: "text-sm font-semibold text-neutral-200", children: "Orders (Last 14 Days)" })] }), _jsx("div", { className: "space-y-1", children: analytics.orders_by_day.slice(-7).map((day) => {
                                            const maxCount = Math.max(...analytics.orders_by_day.map((d) => d.count), 1);
                                            const pct = (day.count / maxCount) * 100;
                                            return (_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "w-20 text-right text-xs text-neutral-500", children: day.date.slice(5) }), _jsx("div", { className: "flex-1 rounded-full bg-neutral-800 h-2 overflow-hidden", children: _jsx("div", { className: "h-2 rounded-full bg-violet-500", style: { width: `${pct}%` } }) }), _jsx("span", { className: "w-8 text-right text-xs text-neutral-400", children: day.count })] }, day.date));
                                        }) })] }))] })), activeTab === "sellers" && (_jsxs("div", { className: "rounded-xl border border-neutral-800 bg-neutral-900", children: [_jsx("div", { className: "border-b border-neutral-800 p-4", children: _jsx("h3", { className: "font-semibold text-neutral-100", children: "Platform Sellers" }) }), sellers.length === 0 ? (_jsx("div", { className: "p-8 text-center text-sm text-neutral-500", children: "No sellers yet." })) : (_jsx("div", { className: "divide-y divide-neutral-800", children: sellers.map((seller) => (_jsxs("div", { className: "flex items-center justify-between p-4", children: [_jsxs("div", { children: [_jsx("p", { className: "font-medium text-neutral-200", children: seller.business_name }), _jsxs("p", { className: "text-xs text-neutral-500", children: [seller.email, " \u00B7 ", seller.wallet_address.slice(0, 10), "..."] })] }), _jsx("span", { className: cn("rounded-full px-2 py-0.5 text-[11px] font-medium", seller.status === "active" ? "bg-emerald-900/60 text-emerald-300" :
                                                seller.status === "suspended" ? "bg-red-900/60 text-red-300" :
                                                    "bg-neutral-700 text-neutral-300"), children: seller.status })] }, seller.id))) }))] })), activeTab === "webhooks" && (_jsxs("div", { className: "rounded-xl border border-neutral-800 bg-neutral-900", children: [_jsx("div", { className: "border-b border-neutral-800 p-4", children: _jsx("h3", { className: "font-semibold text-neutral-100", children: "Webhook Logs" }) }), webhookLogs.length === 0 ? (_jsx("div", { className: "p-8 text-center text-sm text-neutral-500", children: "No webhook events yet." })) : (_jsx("div", { className: "divide-y divide-neutral-800", children: webhookLogs.map((log) => (_jsxs("div", { className: "flex items-center justify-between p-4", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm font-medium text-neutral-200", children: log.event_type }), _jsxs("div", { className: "mt-0.5 flex items-center gap-2 text-xs text-neutral-500", children: [_jsx("span", { children: formatDateTime(log.timestamp) }), log.order_id && _jsxs("span", { children: ["\u00B7 ", log.order_id.slice(0, 8)] }), _jsxs("span", { children: ["\u00B7 ", log.source] })] })] }), _jsxs("span", { className: cn("rounded-full px-2 py-0.5 text-[11px] font-medium", log.status === "processed" ? "bg-emerald-900/60 text-emerald-300" :
                                                log.status === "failed" ? "bg-red-900/60 text-red-300" :
                                                    "bg-neutral-700 text-neutral-300"), children: [log.http_status ? `${log.http_status} · ` : "", log.status] })] }, log.id))) }))] })), activeTab === "chat" && (_jsx(AgentChat, { role: "admin", userId: projectId, variant: "panel", className: "h-[32rem]", placeholder: "Ask about analytics, sellers, or webhook issues..." }))] }))] }));
}
//# sourceMappingURL=AdminDashboard.js.map