type WsEventType = "order_state_changed" | "payout_released" | "dispute_created" | "dispute_resolved" | "order_finalized" | "connected" | "disconnected" | "error";
type WsListener<T = unknown> = (data: T) => void;
interface WsClientConfig {
    baseUrl: string;
    apiKey: string;
    reconnectDelayMs?: number;
    maxReconnectDelayMs?: number;
}
export declare class FlowStateWsClient {
    private baseUrl;
    private apiKey;
    private reconnectDelay;
    private maxReconnectDelay;
    private ws;
    private listeners;
    private shouldReconnect;
    private reconnectTimer;
    private currentDelay;
    constructor({ baseUrl, apiKey, reconnectDelayMs, maxReconnectDelayMs, }: WsClientConfig);
    connect(): void;
    disconnect(): void;
    on<T = unknown>(event: WsEventType, listener: WsListener<T>): () => void;
    off<T = unknown>(event: WsEventType, listener: WsListener<T>): void;
    private emit;
    private openSocket;
    private scheduleReconnect;
}
export {};
//# sourceMappingURL=wsClient.d.ts.map