"use client";
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { MessageCircle, X } from "lucide-react";
import { AgentChat } from "./AgentChat";
import { clsx } from "clsx";
function cn(...args) {
    return clsx(...args);
}
export function BuyerChat({ userId, className }) {
    const [open, setOpen] = useState(false);
    return (_jsxs("div", { className: cn("fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3", className), children: [open && (_jsx(AgentChat, { role: "buyer", userId: userId, variant: "floating", placeholder: "Ask about your order..." })), _jsx("button", { onClick: () => setOpen((v) => !v), className: "flex h-12 w-12 items-center justify-center rounded-full bg-violet-600 text-white shadow-lg hover:bg-violet-500 transition-colors", "aria-label": open ? "Close chat" : "Open buyer chat", children: open ? _jsx(X, { className: "h-5 w-5" }) : _jsx(MessageCircle, { className: "h-5 w-5" }) })] }));
}
//# sourceMappingURL=BuyerChat.js.map