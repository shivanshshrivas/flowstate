import { type ReactNode } from "react";
import { type FlowStateConfig } from "./types/index";
import { FlowStateApiClient } from "./apiClient";
import { FlowStateWsClient } from "./wsClient";
interface FlowStateContextValue {
    config: FlowStateConfig;
    contracts: {
        escrowStateMachine: `0x${string}`;
        disputeResolver: `0x${string}`;
        paymentSplitter: `0x${string}`;
        mockRLUSD: `0x${string}`;
    };
    apiClient: FlowStateApiClient | null;
    wsClient: FlowStateWsClient | null;
}
export interface FlowStateProviderProps {
    config: FlowStateConfig;
    contractAddresses?: {
        escrowStateMachine?: `0x${string}`;
        disputeResolver?: `0x${string}`;
        paymentSplitter?: `0x${string}`;
        mockRLUSD?: `0x${string}`;
    };
    children: ReactNode;
}
export declare function FlowStateProvider({ config, contractAddresses, children, }: FlowStateProviderProps): import("react/jsx-runtime").JSX.Element;
export declare function useFlowState(): FlowStateContextValue;
export {};
//# sourceMappingURL=FlowStateProvider.d.ts.map