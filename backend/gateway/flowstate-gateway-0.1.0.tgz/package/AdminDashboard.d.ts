export interface AdminDashboardProps {
    projectId: string;
    className?: string;
}
export declare function AdminDashboard({ projectId, className }: AdminDashboardProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AdminDashboard.d.ts.map