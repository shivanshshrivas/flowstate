import type { Order, ShippingOption, PayoutSchedule, SellerMetrics, PayoutRecord, Seller, PlatformAnalytics, WebhookEvent, AgentResponse } from "./types/index";
export interface FlowStateApiClientConfig {
    baseUrl: string;
    apiKey: string;
}
export declare class FlowStateApiClient {
    private baseUrl;
    private apiKey;
    constructor({ baseUrl, apiKey }: FlowStateApiClientConfig);
    private request;
    createOrder(input: {
        seller_id: string;
        buyer_wallet: string;
        seller_wallet: string;
        address_from: {
            name: string;
            company?: string;
            street1: string;
            street2?: string;
            city: string;
            state: string;
            zip: string;
            country: string;
            phone?: string;
            email?: string;
        };
        address_to: {
            name: string;
            company?: string;
            street1: string;
            street2?: string;
            city: string;
            state: string;
            zip: string;
            country: string;
            phone?: string;
            email?: string;
        };
        parcel: {
            length: number;
            width: number;
            height: number;
            distanceUnit: "cm" | "in";
            weight: number;
            massUnit: "g" | "kg" | "lb" | "oz";
        };
        items: Array<{
            externalItemId?: string;
            name: string;
            quantity: number;
            unitPriceUsd: number;
            weightOz?: number;
        }>;
    }): Promise<{
        order_id: string;
        shipping_options: ShippingOption[];
        escrow_address: string;
        subtotal_usd: number;
    }>;
    selectShipping(orderId: string, input: {
        rate_id: string;
    }): Promise<{
        escrow_amount_token: string;
        exchange_rate: number;
        label_cid: string;
        total_usd: number;
        shipping_cost_usd: number;
    }>;
    confirmEscrow(orderId: string, input: {
        tx_hash: string;
    }): Promise<{
        status: string;
        invoice_cid: string;
        payout_schedule: PayoutSchedule[];
    }>;
    confirmLabelPrinted(orderId: string, input: {
        seller_wallet: string;
    }): Promise<{
        status: string;
        payout_amount_token: string;
        tx_hash: string;
    }>;
    finalizeOrder(orderId: string): Promise<{
        status: string;
        final_payout_token: string;
        platform_fee_token: string;
        tx_hash: string;
    }>;
    getOrder(orderId: string): Promise<{
        order: Order;
        items: Order["items"];
    }>;
    listOrders(filters?: {
        buyer_wallet?: string;
        seller_id?: string;
        status?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        orders: Order[];
        total: number;
    }>;
    getShippingRates(params: {
        address_from: Record<string, string>;
        address_to: Record<string, string>;
        parcel: Record<string, unknown>;
    }): Promise<{
        rates: ShippingOption[];
    }>;
    trackShipment(orderId: string): Promise<{
        tracking_number: string;
        carrier: string;
        status: string;
        events: Array<{
            timestamp: string;
            description: string;
            location: string;
        }>;
    }>;
    onboardSeller(input: {
        business_name: string;
        wallet_address: string;
        email: string;
        address: Record<string, string>;
        payout_config?: Record<string, number>;
    }): Promise<{
        seller_id: string;
    }>;
    getSellerOrders(sellerId: string, filters?: {
        status?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        orders: Order[];
        total: number;
    }>;
    getSellerMetrics(sellerId: string): Promise<SellerMetrics>;
    getSellerPayouts(sellerId: string): Promise<{
        payouts: PayoutRecord[];
    }>;
    createDispute(input: {
        order_id: string;
        buyer_wallet: string;
        description: string;
        evidence_ipfs_cid?: string;
    }): Promise<{
        dispute_id: string;
    }>;
    respondToDispute(disputeId: string, input: {
        seller_wallet: string;
        description: string;
        evidence_ipfs_cid?: string;
    }): Promise<{
        status: string;
    }>;
    resolveDispute(disputeId: string, input: {
        outcome: "refund_buyer" | "release_seller" | "partial";
        refund_bps?: number;
        notes?: string;
    }): Promise<{
        status: string;
        tx_hash: string;
    }>;
    getPlatformAnalytics(projectId: string): Promise<PlatformAnalytics>;
    getPlatformSellers(projectId: string): Promise<{
        sellers: Seller[];
    }>;
    getGasCosts(projectId: string): Promise<{
        avg_gas_price_gwei: number;
        total_gas_spent_xrp: number;
        transactions: number;
    }>;
    registerWebhook(input: {
        url: string;
        events: string[];
        secret?: string;
    }): Promise<{
        webhook_id: string;
        secret: string;
    }>;
    getWebhookLogs(filters?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        logs: WebhookEvent[];
        total: number;
    }>;
    chatWithAgent(input: {
        role: "buyer" | "seller" | "admin";
        user_id: string;
        message: string;
        session_id?: string;
    }): Promise<AgentResponse>;
    createProject(input: {
        name: string;
        webhook_url?: string;
    }): Promise<{
        project_id: string;
        api_key: string;
    }>;
    rotateApiKey(projectId: string): Promise<{
        api_key: string;
    }>;
}
//# sourceMappingURL=apiClient.d.ts.map